## To get started

1. `npm i` or `yarn install`
2. `nodemon main.js` or `node main.js`
