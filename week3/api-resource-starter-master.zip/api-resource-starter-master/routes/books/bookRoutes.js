const express = require('express');
const router = express.Router();

// add router code here
// 1. get /
//   a. and query parameters to filter and search by 
// 2. post /
// 3. get /:id
// 4. put /:id
// 5. delete /:id


module.exports = router;